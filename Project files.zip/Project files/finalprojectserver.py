import socket
import matplotlib.pyplot as plt
import pickle
import cv2
import cvlib as cv
from cvlib.object_detection import draw_bbox


HEADERSIZE = 10

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(('HarshaVardhan', 12345))
s.listen(5)
while True:
    print ("waiting for connection")
    csoc,addr=s.accept()
    print(addr)
    print("connection accepted")

    full_msg = b''
    new_msg = True
    while True:
        msg = csoc.recv(1024)
        if new_msg:
            #print("new msg len:",msg[:HEADERSIZE])
            msglen = int(msg[:HEADERSIZE])
            new_msg = False

        #print(f"full message length: {msglen}")

        full_msg += msg

        #print(len(full_msg))
        #print("receiving image")
        if len(full_msg)-HEADERSIZE == msglen:
            #print("full msg recvd")
            #print(full_msg[HEADERSIZE:])
            print('opening image')
            recv_image=pickle.loads(full_msg[HEADERSIZE:])
            recv_image=cv2.imwrite("usbcam1.jpg",recv_image)
            im = cv2.imread("usbcam1.jpg")
            bbox, label, conf = cv.detect_common_objects(im)
            output_image = draw_bbox(im, bbox, label, conf)
            plt.figure(figsize=(6,3))
            plt.imshow(output_image)
            plt.show()
            count= str(label.count('car'))
            if count=='':
	             count='0'
            new_msg = True
            full_msg = b"" 
            csoc.send(bytes(count,"utf-8"))
            csoc.close()
            break
    