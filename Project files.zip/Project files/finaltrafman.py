import socket            
import cv2
import pickle

HEADERSIZE=10
# Create a socket object
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)        
 
# Define the port on which you want to connect
port = 12345               
 
# connect to the server on local computer
#s.connect(('127.0.0.1', 12345))
s.connect(('HarshaVardhan', 12345))

#send image
#print(f"Connection from {address} has been established.")
some_image=cv2.imread("/home/harsha09/Densitytraff/image.jpg")
msg = pickle.dumps(some_image)
msg = bytes(f'{len(msg):<{HEADERSIZE}}', "utf-8")+msg
#print(msg)
s.send(msg)
count = s.recv(1024)
print("no of cars:")
print(int(count.decode("utf-8")))



# receive data from the server and decoding to get the string.
#print (s.recv(1024).decode())
# close the connection
s.close()