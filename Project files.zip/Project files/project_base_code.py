d={"lane1":10,"lane2":6,"lane3":2,"lane4":1}
bd={"lane1":1,"lane2":2,"lane3":0,"lane4":0}#back-up dictionary
def new_count(d):#new count returns fresh images of the remaining lanes in the cycle.
    for key in d:#in the final program, add extra "if" statements to allocate right image to right lanes in the dictionary.
        d[key]=int(input(print("enter new value for ",key)))#input is the function "count_image" which returns the no of vehicles.
    

def free_lane(d,bd):
      print(d)
      zl=[]
      zf=0 #zero-flag
      o=[]
      di=[]
      ndi=[]
      flag=0#equal-lane-flag
      l=[]
      for key in d:
          l.append(d[key])
      l.sort()
      print(l)
      #add code block to check if all lanes are empty.
      try:#to check if two or more lanes are empty but not all.
          for i in range(len(l)):
              if l[i]==l[i+1]==0:
                  print("Two or more lanes are empty!")
                  zf=1
                  break
             
                  
      except:
          pass
      if zf==1:#to free one of the lanes which are having vehicles.
          for i in range(len(l)):
              if l[i]!=0:
                  zl.append(l[i])
          l=[]
          for i in range(len(zl)):
              l.append(zl[i])
          
      try:# checking for duplicate values i.e.,equal number of vehicles in 2 or more lanes.
        for i in range(len(l)):
          if l[i]==l[i+1]:
              if l[i]==l[-1]:
               flag=1
              else:
               flag=0
              break
      except:
          pass
      if flag==1: #if there are equal number of vehicles in two or more lanes 
          for i in range(len(l)):
              if l[i]==l[i+1]:
      
                    for key in d:
                        if d[key]==l[i]:
                #print(key)
                            di.append(key)#di contains the lanes having equal number of vehicles.

                                
                    break
          for k in bd:
               o.append(bd[k])
               o.sort()  # o is the back-up counter part of l.
          for j in range(len(o)):
             for key in bd:
                if o[j]==bd[key]: #to store the back-up keys in ascending order in the list ndi.
                    ndi.append(key)

          new=[]
          for i in ndi:
              for j in di:
                   if i==j:
                     new.append(j)# this finally sorts the keys of di in ascending order.
          for key in d:
              if new[-1]==key:
                  print(key," is freed!")
                  
                  del(d[key])
                  break
          new_count(d)
          free_lane(d,bd)
           
              
      else:
          #first back-up the previous cycle lane data.
          for k in d:
               for key in bd:
                   if k==key:
                       bd[key]=d[key]
          #then start with processing the current data
          for key in d:
                  if len(d)==1:#meaning there is only one lane remaining.
                      k=key  #assigning last remaining lane in the dictionary to the variable k.
                  if l[-1]==d[key]:
                      print(key," is freed!")
                      
                      del(d[key])
                      break
          if len(d)!=0: #if lanes are remaining
              new_count(d)
              free_lane(d,bd)
          else:#if there are no lanes remaining.
             d={"lane1":0,"lane2":0,"lane3":0,"lane4":0}
             new_count(d)
             del(d[k]) #this is to not put the last freed lane into loop.
             free_lane(d,bd)
 

   
 
free_lane(d,bd)
   
          
