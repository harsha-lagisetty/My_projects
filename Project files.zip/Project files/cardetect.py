import cv2
import matplotlib.pyplot as plt
import cvlib as cv
from cvlib.object_detection import draw_bbox
import tensorflow as tf

print(tf.__version__)
def count_vehicle(inimage):
    im = cv2.imread(inimage)
    bbox, label, conf = cv.detect_common_objects(im)
    output_image = draw_bbox(im, bbox, label, conf)
    cv2.imwrite("detected.jpg",output_image)
    plt.imshow(output_image)
    plt.show()
    return str(label.count('car'))



count1=count_vehicle(r"C:\Users\lhvar\Downloads\traffic1.jpg")
print("Number of detected Vehicles: ",count1)
#imsource= cv2.imread ('C:/Users/lhvar/Downloads/sample.jpg')
#print(imsource)

"""count2=count_vehicle("line.jpg")
count3=count_vehicle("test sample - toy car.jfif")
print(count1)
print(count2)
print(count3)
c=int(count1)+int(count2)
print(c)"""