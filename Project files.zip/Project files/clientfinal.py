import socket
import pickle
import cv2
from picamera import PiCamera
from time import sleep

def send_image(im):
    HEADERSIZE = 10

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(("HarshaVardhan",12345))

    # now our endpoint knows about the OTHER endpoint.
   # clientsocket, address = s.accept()
    #print(f"Connection from {address} has been established.")
    some_image=cv2.imread(im)
    #d = {1:"hi", 2: "there"}
    msg = pickle.dumps(some_image)
    msg = bytes(f"{len(msg):<{HEADERSIZE}}", 'utf-8')+msg
    #print(msg)
    print("sending image")
    s.send(msg)
    count = s.recv(1024)
    s.close()
    return int(count.decode("utf-8"))

def capusb(id):
    cam = cv2.VideoCapture(id)
    ret, image = cam.read()
#     cv2.imshow('Imagetest',image)

    cv2.imwrite('/home/harsha09/Densitytraff/traffic.jpg', image)
    
    cam.release()
    count = send_image('/home/harsha09/Densitytraff/traffic.jpg')
    return count

def cappi():
    camera = PiCamera()
    camera.start_preview()
    sleep(5)
    camera.capture('/home/harsha09/Densitytraff/image.jpg')
    camera.stop_preview()
    count = send_image('/home/harsha09/Densitytraff/image.jpg')
    return count
                                                                                                                                                                                                                                                                                                                                                            